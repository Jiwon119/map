import React, { useEffect } from 'react'
import KakaoMapScript from './KakaoMapScript'
import Layout from '../layout/Layout';
import styles from './Main.module.css';
import Directions from './Directions';

function Main() {
  useEffect(() => {
    KakaoMapScript();
  }, [])


  return (
    <Layout>
      <div className={styles.body}>
        <div className={styles.content}>
          <Directions />
        </div> 
        <div className={styles.map}>
            <div id='kakaoMap' style={{width: "100%", height:"100%" }}></div>

        </div>  
      </div>

    </Layout>
    
    
  )
}

export default Main