const { kakao } = window;

export default function KakaoMapScript() {

    // 버튼 클릭 이벤트
    var startMarkerBtn = document.getElementById('startMarkerBtn')
    startMarkerBtn.onclick = () => startMarkerClick('MARKER')
    var endMarkerBtn = document.getElementById('endMarkerBtn')
    endMarkerBtn.onclick = () => endMarkerClick('MARKER')
    var startInput = document.getElementById('startInput')
    var endInput = document.getElementById('endInput')
    
    var mapContainer = document.getElementById('kakaoMap'), // 지도를 표시할 div 
    mapOption = {
        center: new kakao.maps.LatLng(37.39279, 126.97344), // 지도의 중심좌표
        level: 4, // 지도의 확대 레벨
        mapTypeId : kakao.maps.MapTypeId.ROADMAP // 지도종류
    }; 

    // 지도를 생성한다 
    var map = new kakao.maps.Map(mapContainer, mapOption); 

    var startOptions = { // Drawing Manager를 생성할 때 사용할 옵션입니다
        map: map, // Drawing Manager로 그리기 요소를 그릴 map 객체입니다
        drawingMode: [ // drawing manager로 제공할 그리기 요소 모드입니다
            kakao.maps.drawing.OverlayType.MARKER
        ],
        // 사용자에게 제공할 그리기 가이드 툴팁입니다
        guideTooltip: ['draw', 'drag', 'edit'], 
        // 사용자에게 도형을 그릴때, 드래그할때, 수정할때 가이드 툴팁을 표시하도록 설정합니다
        markerOptions: { // 마커 옵션입니다 
            draggable: true, // 마커를 그리고 나서 드래그 가능하게 합니다 
            removable: false,
            markerImages: [
                {
                    src: 'https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/red_b.png',
                    width: 50,
                    height: 45,
                    dragImage: {
                        src: 'https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/red_drag.png',
                        width : 50, // 마커 크기
                        height : 64, // 마커 크기
                    }
                }

            ]
        }
    };

    var endOptions = { // Drawing Manager를 생성할 때 사용할 옵션입니다
        map: map, // Drawing Manager로 그리기 요소를 그릴 map 객체입니다
        drawingMode: [ // drawing manager로 제공할 그리기 요소 모드입니다
            kakao.maps.drawing.OverlayType.MARKER
        ],
        // 사용자에게 제공할 그리기 가이드 툴팁입니다
        // 사용자에게 도형을 그릴때, 드래그할때, 수정할때 가이드 툴팁을 표시하도록 설정합니다
        markerOptions: { // 마커 옵션입니다 
            draggable: true, // 마커를 그리고 나서 드래그 가능하게 합니다 
            removable: false,
            markerImages: [
                {
                    src: 'https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/blue_b.png',
                    width: 50,
                    height: 45,
                    dragImage: {
                        src: 'https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/blue_drag.png',
                        width : 50, // 마커 크기
                        height : 64, // 마커 크기
                    }
                }

            ]
        }
    };

    var startMarker, endMarker = false;

    // 위에 작성한 옵션으로 Drawing Manager를 생성
    var startmanager = new kakao.maps.drawing.DrawingManager(startOptions);
    var endManager = new kakao.maps.drawing.DrawingManager(endOptions);

    // 버튼 클릭 시 호출되는 핸들러
    function startMarkerClick(type) {
        if(!startMarker){
            startMarker = true;

            // 클릭한 그리기 요소 타입을 선택
            startmanager.select(kakao.maps.drawing.OverlayType[type]);
        }else{
        }
    }
    // 버튼 클릭 시 호출되는 핸들러
    function endMarkerClick(type) {
        if(!endMarker){
            endMarker = true;
            // 클릭한 그리기 요소 타입을 선택
            endManager.select(kakao.maps.drawing.OverlayType[type]);
        }
    }

    // 마커 등록시 주소 출력
    startmanager.addListener('drawend', function() {
        var data = startmanager.getData()
        console.log(data['marker'][0]);
        startInput.value = `x:${data['marker'][0].x} y:${data['marker'][0].y}`;
    });

    endManager.addListener('drawend', function() {
        var data = endManager.getData()
        console.log(data['marker'][0]);
        endInput.value = `x:${data['marker'][0].x} y:${data['marker'][0].y}`;
    });
}