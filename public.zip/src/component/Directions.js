import React from 'react'
import styles from './Directions.module.css';
import { IoFlagSharp } from 'react-icons/io5'

function Directions() {
  return (
    <div className={styles.frame}>
        <div className={styles.inputGroup}>
            출발
            <input 
                id="startInput"
                className={styles.input} 
                type="text" 
                
                placeholder='출발지'/>
            <button 
                id='startMarkerBtn'
                className={styles.markerBtn}>
                    <IoFlagSharp className={styles.icon}/>출발지 선택
            </button>
        </div>
        <div className={styles.inputGroup}>
            도착
            <input 
                id="endInput"
                className={styles.input} 
                type="text" 
                placeholder='도착지'/>

            <button 
                id='endMarkerBtn'
                className={styles.markerBtn}>
                    <IoFlagSharp className={styles.icon}/>도착지 선택
            </button>
        </div>

        <button
            className={styles.btn}>
            길찾기 &gt;
        </button>



    </div>
  )
}

export default Directions