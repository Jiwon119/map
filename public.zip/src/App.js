import './App.css';
import Main from './component/Main';

function App() {
  return (
    <div>
      <Main />
    </div>
  );
}

export default App;
